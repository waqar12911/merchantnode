<p> Your Nextlayer Two-Factor Sovereign Code : <?php echo $verify_email_code; ?> </p>
