<p> Your Merchant Panel reset password verification code is : <?php echo $verify_email_code; ?> </p>
