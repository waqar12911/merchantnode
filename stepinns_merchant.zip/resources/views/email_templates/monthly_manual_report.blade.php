<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <div>
               <h1>Monthly Transaction Report due Month: {{$month}} and year: {{$year}}</h1>
                
        </div>
    </body>
</html>